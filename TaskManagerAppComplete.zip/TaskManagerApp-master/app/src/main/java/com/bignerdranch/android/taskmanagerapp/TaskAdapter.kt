package com.bignerdranch.android.taskmanagerapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bignerdranch.android.taskmanagerapp.databinding.ItemTaskBinding

class TaskAdapter(

    private val tasks: List<TaskEntity>,
    private val onEditClick: (TaskEntity) -> Unit,
    private val onShareClick: (TaskEntity) -> Unit,
    private val onDeleteClick: (TaskEntity) -> Unit

) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {


    inner class TaskViewHolder(private val binding: ItemTaskBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(task: TaskEntity) {

            binding.textTaskTitle.text = task.title

            binding.buttonEdit.setOnClickListener { onEditClick(task) }
            binding.buttonShare.setOnClickListener { onShareClick(task) }
            binding.buttonDelete.setOnClickListener { onDeleteClick(task) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {

        val binding = ItemTaskBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return TaskViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {

        holder.bind(tasks[position])
    }

    override fun getItemCount(): Int = tasks.size
}

package com.bignerdranch.android.taskmanagerapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TaskListViewModel(private val repository: TaskRepository) : ViewModel() {

    val allTasks: StateFlow<List<TaskEntity>> =
        repository.allTasks
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun insertTask(task: TaskEntity) {

        viewModelScope.launch {

            repository.insertTask(task)
        }
    }

    fun updateTask(task: TaskEntity) {

        viewModelScope.launch {

            repository.updateTask(task)
        }
    }

    fun deleteTask(task: TaskEntity) {

        viewModelScope.launch {

            repository.deleteTask(task)
        }
    }

    suspend fun getTaskById(id: Int): TaskEntity? {

        return repository.getTaskById(id)
    }
}

class TaskListViewModelFactory(private val repository: TaskRepository) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {

        if (modelClass.isAssignableFrom(TaskListViewModel::class.java)) {

            return TaskListViewModel(repository) as T
        }

        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

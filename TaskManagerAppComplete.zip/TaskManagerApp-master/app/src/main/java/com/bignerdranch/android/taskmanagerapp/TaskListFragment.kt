package com.bignerdranch.android.taskmanagerapp


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.bignerdranch.android.taskmanagerapp.databinding.FragmentTaskListBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*



class TaskListFragment : Fragment() {

    private var _binding: FragmentTaskListBinding? = null

    private val binding get() = _binding!!

    private lateinit var taskAdapter: TaskAdapter

    private val viewModel: TaskListViewModel by viewModels {

        TaskListViewModelFactory(

            TaskRepository(
                AppDatabase.getDatabase(requireContext()).taskDao()
            )
        )
    }

    override fun onCreateView(

        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View {

        _binding = FragmentTaskListBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        taskAdapter = TaskAdapter(

            emptyList(),

            onEditClick = { task ->

                val bundle = Bundle()

                bundle.putInt("taskId", task.id)
                findNavController().navigate(R.id.action_taskListFragment_to_addTaskFragment, bundle)
            },
            onShareClick = { task ->

                shareTask(task)
            },
            onDeleteClick = { task ->

                viewModel.deleteTask(task)
            }
        )

        binding.recyclerViewTasks.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewTasks.adapter = taskAdapter

        binding.buttonAddTask.setOnClickListener {

            findNavController().navigate(R.id.action_taskListFragment_to_addTaskFragment)
        }

        viewLifecycleOwner.lifecycleScope.launch {

            viewModel.allTasks.collectLatest { tasks ->


                val today = SimpleDateFormat("MMMM d", Locale.getDefault()).format(Date())

                val todayTasks = tasks.filter { it.date == today }

                taskAdapter = TaskAdapter(

                    todayTasks,

                    onEditClick = { task ->

                        val bundle = Bundle()

                        bundle.putInt("taskId", task.id)
                        findNavController().navigate(R.id.action_taskListFragment_to_addTaskFragment, bundle)
                    },

                    onShareClick = { task ->

                        shareTask(task)
                    },

                    onDeleteClick = { task ->

                        viewModel.deleteTask(task)
                    }
                )
                binding.recyclerViewTasks.adapter = taskAdapter
            }
        }
    }

    private fun shareTask(task: com.bignerdranch.android.taskmanagerapp.TaskEntity) {

        val shareText = "Task: ${task.title}\nDetails: ${task.details}"
        val sendIntent = android.content.Intent().apply {

            action = android.content.Intent.ACTION_SEND
            putExtra(android.content.Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
        }

        val shareIntent = android.content.Intent.createChooser(sendIntent, "Share task via")

        startActivity(shareIntent)
    }

    override fun onDestroyView() {

        super.onDestroyView()
        _binding = null
    }
}

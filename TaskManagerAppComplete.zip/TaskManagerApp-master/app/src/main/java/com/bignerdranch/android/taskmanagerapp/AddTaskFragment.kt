package com.bignerdranch.android.taskmanagerapp

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bignerdranch.android.taskmanagerapp.databinding.FragmentAddTaskBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AddTaskFragment : Fragment() {

    private var _binding: FragmentAddTaskBinding? = null

    private val binding get() = _binding!!

    private var selectedDate: String = ""

    private var editingTaskId: Int = -1

    private val viewModel: TaskListViewModel by viewModels {

        TaskListViewModelFactory(

            TaskRepository(
                AppDatabase.getDatabase(requireContext()).taskDao()
            )
        )
    }

    override fun onCreateView(

        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View {

        _binding = FragmentAddTaskBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)

        val recurrenceOptions = listOf("None", "Daily", "Weekly", "Bi-Weekly", "Monthly")

        val adapter = android.widget.ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            recurrenceOptions
        )

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerRecurrence.adapter = adapter


        binding.buttonSelectDate.setOnClickListener {
            showDatePicker()
        }


        editingTaskId = arguments?.getInt("taskId", -1) ?: -1

        if (editingTaskId != -1) {

            lifecycleScope.launch {

                val task = viewModel.getTaskById(editingTaskId)

                task?.let {

                    binding.editTextTaskTitle.setText(it.title)
                    binding.editTextTaskDetails.setText(it.details)

                    selectedDate = it.date

                    val position = recurrenceOptions.indexOf(it.recurrence)

                    if (position != -1) binding.spinnerRecurrence.setSelection(position)
                }
            }
        }

        binding.buttonSaveTask.setOnClickListener {

            val title = binding.editTextTaskTitle.text.toString()
            val details = binding.editTextTaskDetails.text.toString()
            val recurrence = binding.spinnerRecurrence.selectedItem.toString()

            if (selectedDate.isEmpty()) {

                val dateFormat = SimpleDateFormat("MMMM d", Locale.getDefault())

                selectedDate = dateFormat.format(Date())
            }

            val task = TaskEntity(

                title = title,
                details = details,
                date = selectedDate,
                recurrence = recurrence
            )

            if (editingTaskId != -1) {

                val updatedTask = task.copy(id = editingTaskId)

                viewModel.updateTask(updatedTask)

            } else {

                viewModel.insertTask(task)
            }

            findNavController().navigateUp()
        }
    }

    private fun showDatePicker() {

        val calendar = Calendar.getInstance()

        val datePicker = DatePickerDialog(

            requireContext(),
            { _, year, month, dayOfMonth ->
                val pickedCalendar = Calendar.getInstance()
                pickedCalendar.set(year, month, dayOfMonth)
                val format = SimpleDateFormat("MMMM d", Locale.getDefault())
                selectedDate = format.format(pickedCalendar.time)
            },

            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.show()
    }

    override fun onDestroyView() {

        super.onDestroyView()
        _binding = null
    }
}
